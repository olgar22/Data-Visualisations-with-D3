
function buildPlot() {

  var url = "/samples";
  console.log('inside buildPlot')
  d3.json(url).then(function(response) {
    console.log(response);
    var trace1 = {
      labels: response['otu_ids'],
      values: response['sample_values'],
      type: "pie"
    };
    
    var data = [trace1];
    var layout = {
      title: "Top 10 biocultures",
      height: 800, 
      width: 1000
    };
        
    Plotly.newPlot('pie', data, layout);
  });

}
buildPlot();
  
