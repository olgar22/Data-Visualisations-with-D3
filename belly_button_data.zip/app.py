import os

import pandas as pd
import numpy as np

import sqlalchemy
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine

from flask import Flask, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

df = pd.read_csv("C:/data/belly_button_data.csv")

@app.route("/")
def index():
    """Return the homepage."""
    return render_template("index.html")
df1 = df[['otu_id', 'otu_label', 'sample']].sort_values( by ='sample', ascending = False)
df2 = df1[:10]
print(df2)
@app.route("/samples")
def samples():
    # #sample_data = df.loc[df[sample] > 1, ["otu_id", "otu_label", sample]]
    # # Format the data to send as json
    data = {
        "otu_ids": df2['otu_id'].tolist(),
        "sample_values": df2['sample'].tolist(),
        "otu_labels": df2['otu_label'].tolist()
    }
    return(jsonify(data)) 


if __name__ == "__main__":
    app.run()
